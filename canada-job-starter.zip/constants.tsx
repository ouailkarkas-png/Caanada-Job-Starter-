
import { PricingPlan, FAQItem, Testimonial } from './types';

export const BRAND_NAME = "Canada Career Elite";
export const BRAND_NAME_AR = "كندا كارير إيليت";
export const WHATSAPP_NUMBER = "212600000000"; 
export const WHATSAPP_MESSAGE = "سلام، مهتم بخدمة كندا كارير إيليت. بغيت معلومات كثر على باقة: ";

export const SITE_IMAGES = {
  hero: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1600&q=80",
  resumeService: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=1000&q=80",
  coverLetter: "https://images.unsplash.com/photo-1512428559087-560fa5ceab42?auto=format&fit=crop&w=1000&q=80",
  jobApplications: "https://images.unsplash.com/photo-1521791136364-798a730bb361?auto=format&fit=crop&w=1000&q=80",
  canadaFlag: "https://images.unsplash.com/photo-1554147090-e1221a04a025?auto=format&fit=crop&w=1200&q=85",
  trustSection: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80",
};

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'cv-only',
    name: "باقة الـ CV الاحترافي",
    price: "300 MAD",
    features: [
      "سيرة ذاتية بمعايير ATS الكندية",
      "تصميم عصري واحترافي",
      "اللغة: إنجليزية أو فرنسية",
      "ملف جاهز للتحميل (PDF)",
      "توصيل الملف فـ 48 ساعة"
    ]
  },
  {
    id: 'premium-package',
    name: "باقة البريميوم الكاملة",
    price: "900 MAD",
    isPopular: true,
    features: [
      "السيرة الذاتية (CV) الكندية",
      "رسالة تحفيزية (Cover Letter) مخصصة",
      "استخراج 200+ فرصة عمل حقيقية",
      "تأكيد أن الإيميلات حقيقية ومباشرة",
      "قائمة منظمة بفرص عمل مجانية التقديم",
      "نتا اللي كترسل باش الرد يوصلك مباشرة"
    ]
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "كيفاش غنخلص ثمن الخدمة ديالكم؟",
    answer: "كنخدمو بنظام 'الدفع عند الاستلام'. ملي كتعطينا المعلومات فواتساب، كنصيفطو ليك ظرف تأكيد الطلب لدارك مع شركة التوصيل. ملي كتوصل بالظرف وتخلص التمن (300 أو 900 درهم)، كيبدا الفريق ديالنا الخدمة فوراً. هاد الثمن هو مقابل أتعابنا في تجهيز ملفاتك والبحث ليك عن الفرص."
  },
  {
    question: "واش خاصني نخلص شي حاجة لهاد الشركات الكندية؟",
    answer: "لا أبداً. التقديم للشركات الكندية هو عملية مجانية 100%. حنا كنعطيوك الفرص الحقيقية والإيميلات المباشرة، ونتا فقط كترسل ملفاتك (الـ CV والرسالة) من إيميلك الشخصي لهاد الشركات باش الرد يوصلك نتا مباشرة فإيميلك وهاتفك، وتضمن بلي ما كاين حتى وسيط بينك وبين المشغل."
  },
  {
    question: "علاش أنا اللي كنرسل الإيميلات ماشي نتوما؟",
    answer: "باش نضمنوا الشفافية والخصوصية ديالك. ملي كترسل من إيميلك الشخصي، الشركة الكندية كتشوف بلي نتا مهتم فعلاً، وأي رد أو دعوة للمقابلة (Interview) كتوصلك نتا مباشرة. هادشي كيخليك متحكم فعملية التوظيف ديالك 100%."
  },
  {
    question: "واش هاد الخدمة كتضمن ليا الفيزا؟",
    answer: "لا، نحن خدمة مهنية لتجهيز ملفات الترشيح والبحث عن فرص الشغل الحقيقية. قرار التوظيف والفيزا كيبقى عند المشغل والسلطات الكندية. حنا كنعطيوك ملف احترافي كيرفع حظوظ قبولك لأقصى درجة."
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "عمر الفاسي",
    role: "مهندس مدني",
    content: "عجبني نظام الظرف، خلاني نتيق بلي الخدمة حقيقية. الـ CV طلع احترافي بزاف، صيفطتو للشركات اللي عطاوني وبدات الردود كتوصلني مباشرة فإيميلي الشخصي.",
    avatar: "https://i.pravatar.cc/150?u=omar"
  },
  {
    name: "ليلى التازي",
    role: "ممرضة مجازة",
    content: "قائمة الشركات كانت مدققة والتقديم ليهم مجاني وسهل. بفضل الـ CV الجديد، جاني أول اتصال من شركة فكيبيك باش ندوز مقابلة أونلاين.",
    avatar: "https://i.pravatar.cc/150?u=laila"
  },
  {
    name: "ياسين بناني",
    role: "تقني متخصص",
    content: "باقة البريميوم هناتني من تمارة ديال البحث. عطاوني إيميلات حقيقية ديال شركات كيوظفو دابا. صيفطت ليهم ملفي والردود كتوصلني أنا مباشرة.",
    avatar: "https://i.pravatar.cc/150?u=yassine"
  },
  {
    name: "إلهام صبري",
    role: "مسيرة مبيعات",
    content: "احترافية كبيرة فالمواعيد. الـ CV والـ Cover Letter خلو الملف ديالي يبان عصري وكندي 100%. شكراً ليكم على المجهود.",
    avatar: "https://i.pravatar.cc/150?u=elham"
  }
];
