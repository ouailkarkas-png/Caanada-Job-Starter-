
import React, { useState, useEffect } from 'react';
import Button from './components/Button';
import { 
  PRICING_PLANS, 
  FAQS, 
  TESTIMONIALS, 
  WHATSAPP_NUMBER, 
  BRAND_NAME,
  BRAND_NAME_AR,
  SITE_IMAGES,
  WHATSAPP_MESSAGE
} from './constants';

const App: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const openWhatsApp = (planName?: string) => {
    const message = encodeURIComponent(WHATSAPP_MESSAGE + (planName || "استفسار عام"));
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-red-100 selection:text-red-700" dir="rtl">
      
      {/* Disclaimer Bar */}
      <div className="bg-slate-900 text-white text-[10px] md:text-xs py-2 text-center font-medium px-4">
        ⚠️ تنبيه: نحن خدمة مهنية لتحسين ملفات الترشيح. لا نضمن الحصول على تأشيرة أو عقد عمل. القرار النهائي للمشغلين.
      </div>

      {/* Navigation */}
      <nav className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-lg shadow-md py-3' : 'bg-white py-5'}`}>
        <div className="container mx-auto px-6 flex items-center justify-between flex-row-reverse">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center text-white font-black text-xl">C</div>
            <span className="text-xl font-black tracking-tighter text-slate-900">{BRAND_NAME}</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 font-bold text-sm">
            <a href="#problem" className="hover:text-red-600 transition-colors">علاش حنا؟</a>
            <a href="#process" className="hover:text-red-600 transition-colors">طريقة الخلاص</a>
            <a href="#pricing" className="hover:text-red-600 transition-colors">الأثمنة</a>
            <a href="#testimonials" className="hover:text-red-600 transition-colors">الشهادات</a>
          </div>

          <Button variant="whatsapp" size="sm" onClick={() => openWhatsApp()}>
            واتساب
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-16 pb-24 overflow-hidden">
        <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div className="text-right space-y-8 relative z-10">
            <div className="inline-block px-4 py-1.5 bg-red-50 text-red-600 rounded-full text-xs font-black uppercase tracking-widest border border-red-100">
              🇨🇦 تواصل مباشر ومجاني مع المشغل الكندي
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 leading-[1.1] tracking-tight">
              اجعل ملفك الشخصي يتحدث <span className="text-red-600 italic">بالكندية</span>
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed font-medium max-w-xl">
              كنستخرجو ليك فرص عمل حقيقية وإيميلات مباشرة لشركات كندية. <span className="text-slate-900 font-black underline decoration-red-600">التقديم مجاني تماماً ونتا اللي كترسل باش الرد يوصلك مباشرة.</span> الخلاص ديالنا حتى يوصلك الظرف لدارك.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button variant="primary" size="lg" className="px-10 shadow-2xl shadow-red-500/30" onClick={() => openWhatsApp("Hero Button")}>
                طلب الخدمة دابا (واتساب)
              </Button>
              <Button variant="outline" size="lg" onClick={() => document.getElementById('pricing')?.scrollIntoView()}>
                شوف الأثمنة والباقات
              </Button>
            </div>
            <div className="flex items-center gap-6 pt-6 text-sm font-bold text-slate-400">
              <span className="flex items-center gap-2">✅ إيميلات مدققة</span>
              <span className="flex items-center gap-2">📦 الدفع عند الاستلام</span>
              <span className="flex items-center gap-2">📬 ردود مباشرة لك</span>
            </div>
          </div>
          <div className="relative">
            <div className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl transform lg:rotate-3 border-8 border-white group">
              <img src={SITE_IMAGES.hero} alt="Professional Career Development" className="w-full h-auto object-cover aspect-[4/5] group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
            </div>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-red-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section id="problem" className="py-24 bg-slate-50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight">علاش كتدفع وما كاينش رد؟ ❌</h2>
            <p className="text-slate-500 text-lg font-medium">المشكلة غالباً فالبحث العشوائي وبلي ملف الترشيح ديالك ما محترمش "المعايير الكندية".</p>
            
            <div className="grid md:grid-cols-3 gap-8 pt-12 text-right">
              <div className="bg-white p-8 rounded-3xl shadow-sm space-y-4 border border-slate-100">
                <div className="text-4xl">📧</div>
                <h3 className="text-xl font-black">إيميلات مدققة</h3>
                <p className="text-slate-600 font-medium leading-relaxed text-sm">كنعطيوك إيميلات حقيقية ومباشرة للشركات اللي كتوظف فعلاً، ماشي مواقع وهمية.</p>
              </div>
              <div className="bg-white p-8 rounded-3xl shadow-sm space-y-4 border border-slate-100">
                <div className="text-4xl">🇨🇦</div>
                <h3 className="text-xl font-black">احترافية 100%</h3>
                <p className="text-slate-600 font-medium leading-relaxed text-sm">الـ CV والـ Cover Letter هما الساروت. إيلا ما كانوش مقادين، المشغل ما غيضيعش وقتو معاك.</p>
              </div>
              <div className="bg-white p-8 rounded-3xl shadow-sm space-y-4 border border-slate-100">
                <div className="text-4xl">🤳</div>
                <h3 className="text-xl font-black">تواصل مباشر</h3>
                <p className="text-slate-600 font-medium leading-relaxed text-sm">ملي نتا اللي كترسل إيميلات التقديم (فابور)، الردود والاتصالات كتوصلك نتا مباشرة فإيميلك الشخصي.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process & Payment Section */}
      <section id="process" className="py-24 bg-white relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900">طريقة العمل: واضحة وموثوقة 🤝</h2>
            <p className="text-slate-500 text-lg font-medium">نظام "الخلاص عند الاستلام" لضمان ثقتك التامة في خدماتنا.</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 relative">
            <div className="relative p-8 bg-white rounded-[32px] border-2 border-slate-50 text-right space-y-4 shadow-sm hover:border-red-100 transition-colors">
              <div className="w-12 h-12 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black">01</div>
              <h3 className="text-xl font-black">طلب الخدمة</h3>
              <p className="text-slate-600 text-sm font-medium leading-relaxed">تواصل معنا فواتساب، ختار باقتك وعطينا معلوماتك باش نبحثو ليك على الفرص المناسبة.</p>
            </div>
            
            <div className="relative p-8 bg-red-50 rounded-[32px] border-2 border-red-100 text-right space-y-4 shadow-md">
              <div className="w-12 h-12 bg-red-600 text-white rounded-xl flex items-center justify-center font-black shadow-lg">02</div>
              <h3 className="text-xl font-black text-red-700">الظرف والخلاص</h3>
              <p className="text-slate-700 text-sm font-bold leading-relaxed">كنصيفطو ليك **ظرف تأكيد** لدارك. ملي كتخلص شركة التوصيل وتستلمو، كيبدا الفريق الخدمة فوراً.</p>
            </div>
            
            <div className="relative p-8 bg-white rounded-[32px] border-2 border-slate-50 text-right space-y-4 shadow-sm hover:border-red-100 transition-colors">
              <div className="w-12 h-12 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black">03</div>
              <h3 className="text-xl font-black">تجهيز الملفات</h3>
              <p className="text-slate-600 text-sm font-medium leading-relaxed">كنصاوبو الـ CV والـ Cover Letter وكنجمعو ليك قائمة الشركات المدققة والإيميلات المباشرة.</p>
            </div>
            
            <div className="relative p-8 bg-white rounded-[32px] border-2 border-slate-50 text-right space-y-4 shadow-sm hover:border-red-100 transition-colors">
              <div className="w-12 h-12 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black">04</div>
              <h3 className="text-xl font-black">إرسال الترشيح</h3>
              <p className="text-slate-600 text-sm font-medium leading-relaxed">نتا كترسل ملفاتك الجاهزة للشركات اللي عطيناك (التقديم فابور) باش أي رد يوصلك مباشرة فإيميلك الشخصي.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-20">
            <h2 className="text-4xl md:text-6xl font-black tracking-tight">باقات واضحة وشاملة</h2>
            <p className="text-slate-400 text-xl font-medium">تخلص مقابل الخدمة الاحترافية، والتقديم للشركات يبقى دائماً مجانياً.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto items-stretch">
            {PRICING_PLANS.map((plan) => (
              <div key={plan.id} className={`relative flex flex-col p-10 rounded-[48px] border-2 transition-all duration-500 hover:-translate-y-4 ${plan.isPopular ? 'bg-white text-slate-900 border-red-600 scale-105 shadow-2xl shadow-red-500/10' : 'bg-slate-800 border-slate-700 text-white'}`}>
                {plan.isPopular && (
                  <div className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-red-600 text-white text-[10px] font-black py-2 px-6 rounded-full uppercase tracking-widest shadow-lg">الأكثر طلباً</div>
                )}
                <h3 className="text-2xl font-black mb-2 text-center">{plan.name}</h3>
                <div className="text-5xl font-black text-center mb-10 py-4 border-b border-slate-100/10">{plan.price}</div>
                <ul className="space-y-5 flex-grow mb-12">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-center justify-start gap-3 flex-row-reverse text-right">
                      <span className="text-red-600 font-black">✓</span>
                      <span className="font-bold text-lg leading-snug">{f}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  variant={plan.isPopular ? 'primary' : 'outline'} 
                  fullWidth 
                  size="lg"
                  className="rounded-3xl"
                  onClick={() => openWhatsApp(plan.name)}
                >
                  طلب الخدمة دابا
                </Button>
                {plan.isPopular && (
                   <p className="text-[10px] text-center mt-4 text-slate-400 font-bold">نتا كترسل ملفاتك مباشرة للشركات وبلا وسطاء لضمان الرد الشخصي.</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20 space-y-4">
             <div className="inline-block px-4 py-1.5 bg-green-50 text-green-700 rounded-full text-xs font-black uppercase tracking-widest">نماذج لقصص نجاح حقيقية</div>
             <h2 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">هاد الناس ثاقو فينا وحسنوا ملفاتهم</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="bg-slate-50 p-8 rounded-[40px] border border-slate-100 hover:shadow-xl transition-all duration-500 flex flex-col">
                <p className="text-slate-700 italic font-medium leading-relaxed mb-8 flex-grow text-right">“{t.content}”</p>
                <div className="flex items-center gap-4 flex-row-reverse">
                  <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-2xl object-cover shadow-md" />
                  <div className="text-right">
                    <div className="font-black text-slate-900">{t.name}</div>
                    <div className="text-xs font-bold text-red-600 uppercase tracking-widest">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faqs" className="py-24 bg-slate-50">
        <div className="container mx-auto px-6 max-w-4xl">
           <h2 className="text-3xl md:text-5xl font-black text-center mb-16">أسئلة كتردد بزاف</h2>
           <div className="space-y-4">
             {FAQS.map((faq, i) => (
               <div key={i} className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm">
                  <button 
                    className="w-full p-8 text-right flex items-center justify-between flex-row-reverse group"
                    onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                  >
                    <span className="text-xl font-black text-slate-900 group-hover:text-red-600 transition-colors">{faq.question}</span>
                    <span className={`transform transition-transform text-red-600 font-black ${activeFaq === i ? 'rotate-180' : ''}`}>▼</span>
                  </button>
                  {activeFaq === i && (
                    <div className="px-8 pb-8 text-slate-600 font-medium leading-relaxed text-right animate-in fade-in slide-in-from-top-2">
                      {faq.answer}
                    </div>
                  )}
               </div>
             ))}
           </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-red-600 text-white text-center">
        <div className="container mx-auto px-6 max-w-4xl space-y-10">
           <h2 className="text-4xl md:text-6xl font-black leading-tight">باغي تبدا طريقك لكندا اليوم؟ 🇨🇦</h2>
           <p className="text-xl opacity-90 font-medium">استثمر فمستقبلك بملف احترافي وقائمة شركات مدققة. الردود والاتصالات غتوصلك مباشرة فإيميلك الشخصي لأنك نتا اللي غترسل ليهم!</p>
           <Button variant="secondary" size="lg" className="px-16 py-6 text-xl shadow-2xl bg-white text-red-600 hover:bg-slate-100" onClick={() => openWhatsApp()}>
              تواصل معنا فواتساب دابا
           </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 text-white pt-24 pb-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-16 text-right mb-20">
            <div className="space-y-6">
              <div className="flex items-center gap-2 justify-end">
                <span className="text-2xl font-black tracking-tighter text-white">{BRAND_NAME}</span>
                <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center text-white font-black text-xl">C</div>
              </div>
              <p className="text-slate-400 font-medium leading-relaxed">
                الخدمة رقم 1 بالمغرب لتجهيز ملفات الترشيح للعمل في كندا. ثقة، مصداقية، وتواصل مباشر ومجاني مع الشركات.
              </p>
            </div>
            <div className="space-y-6">
              <h4 className="text-lg font-black border-r-4 border-red-600 pr-4">روابط مهمة</h4>
              <ul className="space-y-4 text-slate-400 font-bold">
                <li><a href="#" className="hover:text-red-500 transition-colors">الرئيسية</a></li>
                <li><a href="#pricing" className="hover:text-red-500 transition-colors">باقات الخدمات</a></li>
                <li><a href="#testimonials" className="hover:text-red-500 transition-colors">قصص النجاح</a></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h4 className="text-lg font-black border-r-4 border-red-600 pr-4">إخلاء مسؤولية</h4>
              <p className="text-[10px] text-slate-500 leading-relaxed italic">
                {BRAND_NAME_AR} هي شركة مغربية مستقلة. نحن لسنا وكالة هجرة. مهمتنا هي تجهيز الملفات والبحث عن الفرص. التقديم للشركات مجاني تماماً والزبون هو المسؤول عن إرسال ملفاته لضمان الرد المباشر.
              </p>
            </div>
          </div>
          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-600 text-[10px] font-bold">
            <p>© {new Date().getFullYear()} {BRAND_NAME}. جميع الحقوق محفوظة بالمغرب.</p>
          </div>
        </div>
      </footer>

      {/* Sticky Mobile Bar */}
      <div className={`fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-xl border-t border-slate-100 z-50 md:hidden flex gap-3 transition-transform duration-500 ${isScrolled ? 'translate-y-0 shadow-[0_-10px_40px_rgba(0,0,0,0.1)]' : 'translate-y-full'}`}>
        <Button variant="whatsapp" fullWidth size="lg" onClick={() => openWhatsApp()}>طلب الخدمة - WhatsApp</Button>
      </div>

    </div>
  );
};

export default App;
